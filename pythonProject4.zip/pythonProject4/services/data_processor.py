# backend/services/data_processor.py
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer
import pandas as pd


class DataProcessor:
    """专业级数据预处理管道"""

    def __init__(self, config: dict):
        config:  {
                "numerical": ['面积', '房龄'],
                "categorical": ['户型', '装修等级', '近地铁','朝向', '区域']
            }

        self.config = config
        self.preprocessor = self._build_preprocessor()
        self.feature_names = []

    def _build_preprocessor(self) -> ColumnTransformer:
        """构建专业级预处理管道"""
        # 数值特征处理
        numerical_transformer = Pipeline(steps=[
            ('scaler', StandardScaler())
        ])

        # 分类特征处理（带稀疏矩阵优化）
        categorical_transformer = Pipeline(steps=[
            ('onehot', OneHotEncoder(
                handle_unknown='ignore',
                sparse_output=False,  # 输出密集矩阵
                drop='if_binary'  # 优化二元特征
            ))
        ])

        # 布尔型特征处理（带类型验证）
        boolean_transformer = Pipeline(steps=[
            ('validate', FunctionTransformer(
                func=lambda x: x.astype(int),
                validate=True  # 启用输入验证
            ))
        ])

        return ColumnTransformer(
            transformers=[
                ('num', numerical_transformer, self.config['numerical']),
                ('cat', categorical_transformer, self.config['categorical'])
            ],
            remainder='drop',  # 明确处理未定义特征
            verbose_feature_names_out=False  # 优化特征名称
        )

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """专业级拟合转换方法"""
        processed = self.preprocessor.fit_transform(df)
        self._set_feature_names(df)
        return pd.DataFrame(processed, columns=self.feature_names)

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """生产级转换方法"""
        processed = self.preprocessor.transform(df)
        return pd.DataFrame(processed, columns=self.feature_names)

    def _set_feature_names(self, df: pd.DataFrame):
        """动态生成特征名称（支持复杂转换）"""
        # 数值特征保留原始名称
        num_features = self.config['numerical']

        # 分类特征生成编码后名称
        cat_encoder = self.preprocessor.named_transformers_['cat'].named_steps['onehot']
        cat_features = cat_encoder.get_feature_names_out(self.config['categorical'])

        self.feature_names = num_features + cat_features.tolist()