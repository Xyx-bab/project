# backend/services/price_predictor.py
import joblib
import pandas as pd
from typing import Dict


class PricePredictor:
    """预测服务封装类"""

    def __init__(self, model_path: str, preprocessor_path: str):

        self.model = joblib.load('data/models/xgboost_model.pkl')
        self.preprocessor = joblib.load('data/models/preprocessor.pkl')

    def predict(self, input_data: Dict) -> float:
        """
        执行预测
        :param input_data: 输入特征字典
            Example:
            {
                "面积": 90,
                "房龄": 5,
                "户型": "两室一厅",
                "装修等级": "精装",
                "近地铁": True,
                "朝向": "南",
                "区域": "浦东"
            }
        """
        # 转换为DataFrame
        input_df = pd.DataFrame([input_data])

        # 数据预处理
        processed = self.preprocessor.transform(input_df)

        # 执行预测
        return round(self.model.predict(processed)[0], 2)