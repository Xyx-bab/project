let currentAngle = 0;
const districts = ['浦东', '闵行', '宝山', '徐汇', '普陀', '杨浦', '长宁', '松江', '嘉定', '黄浦'];
const angleStep = 360 / districts.length;

// 初始化转盘
function initTurntable() {
    const turntable = document.getElementById('turntable');
    turntable.innerHTML = '';

    districts.forEach((district, index) => {
        const sector = document.createElement('div');
        sector.className = 'sector';
        const rotateAngle = index * angleStep;

        // 计算标签旋转补偿角度
        const labelRotate = -rotateAngle + angleStep/2;

        sector.style.cssText = `
            transform: rotate(${rotateAngle}deg);
            transform-origin: 100% 100%;
        `;

        const label = document.createElement('div');
        label.className = 'label';
        label.textContent = district;
        label.style.setProperty('--label-rotate', `${labelRotate}deg`);
        label.style.cssText = `
            transform: 
                translate(-50%, -150%) 
                rotate(${labelRotate}deg);
            left: 50%;
            top: 0;
        `;

        sector.appendChild(label);
        turntable.appendChild(sector);
    });
}

// 获取当前选中区域
function getSelectedDistrict() {
    const normalized = (currentAngle + 90) % 360; // 补偿指针方向
    const index = Math.floor(normalized / angleStep);
    return districts[(districts.length - index) % districts.length];
}

// 显示图表（保持之前的功能）
// ...保持之前的showChart函数...

// 事件监听（添加拖动逻辑）
document.addEventListener('mousedown', (e) => {
    if (e.target.closest('.label')) {
        isDragging = true;
        startAngle = currentAngle;
        document.body.style.cursor = 'grabbing';
    }
});

document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;

    const turntable = document.getElementById('turntable');
    const rect = turntable.getBoundingClientRect();
    const centerX = rect.left + rect.width/2;
    const centerY = rect.top + rect.height/2;
    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
    currentAngle = angle * (180 / Math.PI) + 90;

    turntable.style.transform = `rotate(${currentAngle}deg)`;
});

document.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;
    document.body.style.cursor = 'default';

    const selected = getSelectedDistrict();
    showChart(selected);
});

// 初始化
window.onload = () => {
    initTurntable();
    document.querySelector('.close').addEventListener('click', () => {
        document.getElementById('chartModal').style.display = 'none';
    });
};
// 获取选中区域
function getSelectedDistrict(angle) {
    const normalized = (angle + 360) % 360;
    const index = Math.floor(normalized / angleStep);
    return districts[index % districts.length];
}

// 显示图表
function showChart(district) {
    fetch(`/api/predict/${district}`)
        .then(res => res.json())
        .then(data => {
            const chart = echarts.init(document.getElementById('chartContainer'));
            const option = {
                title: { text: `${district}房价走势`, left: 'center' },
                xAxis: {
                    type: 'category',
                    data: data.history.dates
                },
                yAxis: { type: 'value' },
                series: [{
                    data: data.history.prices,
                    type: 'line',
                    smooth: true,
                    markPoint: {
                        data: [{
                            name: '预测值',
                            value: data.prediction,
                            xAxis: data.history.dates[data.history.dates.length-1],
                            yAxis: data.prediction
                        }]
                    }
                }]
            };
            chart.setOption(option);
            document.getElementById('chartModal').style.display = 'block';
        });
}

// 事件监听
document.getElementById('turntable').addEventListener('click', function(e) {
    currentAngle += angleStep * 3; // 每次旋转3个区域
    this.style.transform = `rotate(${currentAngle}deg)`;

    setTimeout(() => {
        const selected = getSelectedDistrict(currentAngle);
        showChart(selected);
    }, 1500);
});

document.querySelector('.close').addEventListener('click', () => {
    document.getElementById('chartModal').style.display = 'none';
});


// 添加函数定义
function initAllCharts(data) {
    // 示例：在控制台打印数据
    console.log('初始化数据加载完成', data);

    // 或者预加载所有图表
    districts.forEach(district => {
        const chartDiv = document.createElement('div');
        chartDiv.id = `chart-${district}`;
        chartDiv.style.display = 'none';
        document.body.appendChild(chartDiv);
    });
}

// 修改后的初始化调用
window.onload = () => {
    initTurntable();
    fetch('/api/data')
        .then(res => res.json())
        .then(data => {
            initAllCharts(data);
            return data;
        });
};




