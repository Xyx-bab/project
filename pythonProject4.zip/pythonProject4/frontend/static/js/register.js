document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;
    const confirm = document.getElementById('confirmPassword').value;

    console.log(46655465)

    if (password !== confirm) {
        showRegError('两次输入的密码不一致');
        return;
    }

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const result = await response.json();
        if (result.success) {
            alert('注册成功，请登录');
            window.location.href = '/';
        } else {
            showRegError(result.message || '注册失败');
        }
    } catch (error) {
        showRegError('网络连接异常');
    }
});

function showError(msg) {
    const errorEl = document.getElementById('errorMsg');
    errorEl.textContent = msg;
    errorEl.style.display = 'block';
}

function showRegError(msg) {
    const errorEl = document.getElementById('regErrorMsg');
    errorEl.textContent = msg;
    errorEl.style.display = 'block';
}