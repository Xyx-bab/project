// 区域数据
const districts = ['浦东', '闵行', '宝山', '徐汇', '普陀',
                  '杨浦', '长宁', '松江', '嘉定', '黄浦'];

// 初始化页面
function initGrid() {
    const container = document.getElementById('gridContainer');

    districts.forEach(district => {
        const item = document.createElement('div');
        item.className = 'grid-item';
        item.textContent = district;
        item.addEventListener('click', () => showChart(district));
        container.appendChild(item);
    });
}

// 显示图表
let currentChart = null;
function showChart(district) {
    fetch(`/api/predict/${district}`)
        .then(res => res.json())
        .then(data => {
            const chart = echarts.init(document.getElementById('chartContainer'));
            const option = {
                title: { text: `${district}房价走势`, left: 'center' },
                xAxis: {
                    type: 'category',
                    name: "时间",
                    nameLocation : 'center',
                    nameGap :25,
                    nameTextStyle: {
                        color: '#666',
                        fontSize: 14
                    },
                    data: data.history.dates
                },
                yAxis: {
                    type: 'value' ,
                    name: '价格（万元）',
                    nameLocation: 'center',
                    nameGap: 30,
                    nameTextStyle: {
                        color: '#666',
                        fontSize: 14
                    },
                    axisLabel: {
                        formatter: function(value) {
                            return (value / 10000).toFixed(1); // 转换为万元单位
                        }
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            type: 'dashed',
                            color: '#eee'
                        }
                    }
                },
                series: [{
                    data: data.history.prices,
                    type: 'line',
                    smooth: true,
                    markPoint: {
                        data: [{
                            name: '预测值',
                            value: data.prediction,
                            xAxis: data.history.dates[data.history.dates.length-1],
                            yAxis: data.prediction
                        }]
                    }
                }]
            };
            chart.setOption(option);
            document.getElementById('chartModal').style.display = 'block';
        });
}

// 关闭弹窗
document.querySelector('.close-btn').addEventListener('click', () => {
    document.getElementById('chartModal').style.display = 'none';
});

// 初始化
window.onload = () => {
    initGrid();
};