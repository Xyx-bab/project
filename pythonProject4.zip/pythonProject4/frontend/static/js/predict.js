document.getElementById('startPredictionButton').addEventListener('click', async function () {
    // 禁用按钮防止重复提交
    const btn = this;
    btn.disabled = true;
    btn.innerHTML = '<i class="loading-spinner"></i> 正在预测中...';
    try {
        // 收集表单数据
        const formData = {
            '面积': parseFloat(document.getElementById('面积').value),
            '房龄': parseInt(document.getElementById('房龄').value),
            '户型': document.getElementById('户型').value,
            '装修等级': document.getElementById('装修等级').value,
            '区域': document.getElementById('区域').value,
            '朝向': document.getElementById('朝向').value,
            '近地铁': document.getElementById('近地铁').value
        };
        // 数据验证
        // if (!formData.area || formData.area <= 0) {
        //     throw new Error('请输入有效的建筑面积');
        // }
        // if (!formData.age || formData.age < 0) {
        //     throw new Error('房龄不能为负数');
        // }
        // if (!formData.houseType) {
        //     throw new Error('请选择户型');
        // }
        // if (!formData.decoration) {
        //     throw new Error('请选择装修等级');
        // }
        // if (!formData.region) {
        //     throw new Error('请选择所在区域');
        // }
        // if (!formData.orientation) {
        //     throw new Error('请选择房屋朝向');
        // }

        // 发送预测请求
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        // 处理响应
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || '预测服务暂时不可用');
        }

        const result = await response.json();
        const price = result.predicted_price.toFixed(2); // 保留两位小数


         // 改为弹窗操作：
        const modal = document.getElementById('predictionModal');
        const modalContent = document.getElementById('modalContent');

        // 填充内容到弹窗
        modalContent.innerHTML = `
    <div class="result-card">
        <h3>预测结果：${price} 万元</h3>
        <div class="detail-row">
            <span>区域：</span>
            <span>${formData.区域}</span>
        </div>
        <div class="detail-row">
            <span>户型：</span>
            <span>${formData.户型}</span>
        </div>
    </div>
`;

        // 显示弹窗
        modal.style.display = 'flex';

        // 添加关闭事件监听
        modal.querySelector('.modal-close').onclick = () => {
            modal.style.display = 'none';
        };

        // 点击遮罩层关闭
        modal.onclick = (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        };


    } catch (error) {
        // 错误处理
        showErrorAlert(error.message);
    } finally {
        // 恢复按钮状态
        btn.disabled = false;
        btn.innerHTML = '开始预测';
    }
});

// 确保视频加载后自动播放
document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('bgVideo');

    // 处理浏览器自动播放策略
    video.play().catch(error => {
        console.log('自动播放被阻止，需要用户交互');
        // 点击页面任意位置后播放
        document.body.addEventListener('click', function initPlay() {
            video.play();
            document.body.removeEventListener('click', initPlay);
        });
    });

    // 响应式处理（横竖屏适配）
    window.addEventListener('resize', () => {
        const aspectRatio = video.videoWidth / video.videoHeight;
        if (window.innerWidth / window.innerHeight > aspectRatio) {
            video.style.width = '100%';
            video.style.height = 'auto';
        } else {
            video.style.width = 'auto';
            video.style.height = '100%';
        }
    });
});

// 显示错误提示
function showErrorAlert(message) {
    const alertBox = document.createElement('div');
    alertBox.className = 'error-alert';
    alertBox.innerHTML = `
        <i class="warning-icon"></i>
        <span>${message}</span>
    `;

    document.body.appendChild(alertBox);
    setTimeout(() => alertBox.remove(), 3000);
}